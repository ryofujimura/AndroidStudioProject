package com.zybooks.thebanddatabase

data class Band(
    var id: Int = 0,
    var name: String = "",
    var description: String = "") {
}